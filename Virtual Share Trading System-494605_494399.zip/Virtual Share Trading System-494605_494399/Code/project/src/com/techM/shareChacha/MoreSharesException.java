package com.techM.shareChacha;

import com.techM.shareChachaDB.UserDB;

public class MoreSharesException extends Exception {

	public MoreSharesException(String s) {
		// TODO Auto-generated constructor stub
		//super(s);
		
	}

}
