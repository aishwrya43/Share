package com.techM.shareChacha.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.techM.shareChachaBeans.User;
import com.techM.shareChachaDB.UserDB;

/**
 * Servlet implementation class SignUpServlet
 */
public class SignUpServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    /**
     * Default constructor. 
     */
    public SignUpServlet() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
		super.init();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		try {
		User u = new User();
	
		u.setUserID(request.getParameter("userName").substring(0, 3) + Math.round(Math.random() * 1000));
		u.setUserName(request.getParameter("userName"));
		u.setPassword(request.getParameter("password"));
		u.setUserType(request.getParameter("userType"));
		u.setLocation(request.getParameter("location"));
		u.setPhoneNumber(Long.parseLong(request.getParameter("phoneNumber")));
		u.setEmail(request.getParameter("email"));
		
		
		UserDB uDB = new UserDB();
		
		int i = uDB.insertUser(u);
		
		if( i == 1 ) {
			request.setAttribute("userID", u.getUserID());
			
			RequestDispatcher rd = request.getRequestDispatcher("/signin.jsp");
			rd.forward(request, response);
		}
		else {
			throw new Exception();
		}
		} catch (Exception e) {
			request.setAttribute("message", "Sign up not successful. Please try again..");
						
			RequestDispatcher rd = request.getRequestDispatcher("/signup.jsp");
			rd.forward(request, response);
		}
		
	}
	}


