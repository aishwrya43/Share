package com.techM.shareChachaDB;

import java.sql.CallableStatement;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.http.HttpSession;

import com.techM.shareChacha.MoreSharesException;
import com.techM.shareChachaBeans.Company;
import com.techM.shareChachaBeans.Transaction;
import com.techM.shareChachaBeans.User;
import com.techM.shareChachaBeans.UserStock;

public class UserDB {
	private Connection c = null, c2 = null;
	private PreparedStatement p = null, p2 = null;
	private ResultSet r = null, r2 = null;

	public Connection getConnection() {
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");
			return DriverManager.getConnection(
					"jdbc:oracle:thin:@localhost:1521:XE", "system", "system");

		} catch (ClassNotFoundException e) {
			
			return null;
		} catch (SQLException e) {
		
			return null;
		}
	}

	public void closeConnection(Connection c) {
		try {
			c.close();
		} catch (SQLException e) {
			// System.out.println("Could Not Close the Exception" + e);
		}
	}

	public int insertUser(User u) {
		c = getConnection();

		try {
			p = c.prepareStatement("insert into usertable values(?,?,?,?,?,?,?)");

			p.setString(1, u.getUserID());
			p.setString(2, u.getPassword());
			p.setString(3, u.getUserType());
			p.setString(4, u.getUserName());
			p.setString(5, u.getLocation());
			p.setLong(6, u.getPhoneNumber());
			p.setString(7, u.getEmail());

			int i = p.executeUpdate();

			p.close();
			closeConnection(c);

			return i;
		} catch (SQLException e) {
			System.out.println("USer insert " + e);
			return -1;
		}
	}

	public User validateUser(String userID, String password, String userType) {
		c = getConnection();
		System.out.println(userID + password + userType);
		try {
			p = c.prepareStatement("select * from userTable where userID=? and password=? and userType=?");

			p.setString(1, userID);
			p.setString(2, password);
			p.setString(3, userType);

			r = p.executeQuery();
			System.out.println(userID + password + userType);
			User u = new User();
			if (r.next()) {
				u.setUserID(r.getString("userID"));
				u.setPassword(r.getString("password"));
				u.setUserType(r.getString("userType"));
				u.setUserName(r.getString("userName"));
				u.setLocation(r.getString("location"));
				u.setPhoneNumber(r.getLong("phoneNumber"));
				u.setEmail(r.getString("email"));

				r.close();
				p.close();
				closeConnection(c);

				return u;
			} else {
				r.close();
				p.close();
				closeConnection(c);
				return null;
			}

		} catch (SQLException e) {
			System.out.println("User insert " + e);
			return null;
		}
	}

	public int addStock(Company comp, String userID) {
		c = getConnection();
		
		
		Random rand = new Random();
		int availableshares = rand.nextInt(500) + 100;

		try {
			p = c.prepareStatement("insert into CompanyTable values(?,?,?,?,?,?,SYSDATE)");
			p.setString(1, comp.getCompanyID());
			p.setString(2, comp.getCompanyName());
			p.setInt(3, comp.getTotalShares());
			p.setDouble(4, comp.getCurrentPrice());
			
			
			p.setInt(5, availableshares);
			p.setString(6, comp.getSeller());

			int i = 0;
			i = p.executeUpdate();

			p.close();
			// closeConnection(c);

			p2 = c.prepareStatement("insert into StockDetailsTable values(?,?,?,?,SYSDATE)");
			p2.setString(1, userID);
			p2.setString(2, comp.getCompanyID());
			p2.setInt(3, comp.getTotalShares());
			p2.setDouble(4, comp.getCurrentPrice());

			i = i + p2.executeUpdate();

			p2.close();
			closeConnection(c);

			if (i == 2)
				return 2;
			else
				return -1;

		} catch (SQLException e) {
			System.out.println("User insert " + e);
			return -1;
		}
	}

	public ArrayList<Company> getStocks() {
		c = getConnection();

		try {
			p = c.prepareStatement("select companyID, companyName, totalShares, availableshares, currentPrice, seller from CompanyTable");
			r = p.executeQuery();

			ArrayList<Company> alist = new ArrayList<Company>();

			while (r.next()) {
				Company comp = new Company();
				comp.setCompanyID(r.getString(1));
				comp.setCompanyName(r.getString(2));
				comp.setTotalShares(r.getInt(3));
				comp.setAvailableShares(r.getInt(4));
				comp.setCurrentPrice(r.getDouble(5));
				comp.setSeller(r.getString(6));
				// comp.setDateTime(r.getTimestamp(7));

				alist.add(comp);
			}

			r.close();
			p.close();
			closeConnection(c);

			return alist;

		} catch (SQLException e) {
			System.out.println("SQLException1 " + e);
			return null;
		}
	}

	public int updateCompanyTable(Company comp) {
		c = getConnection();

		try {
			p = c.prepareStatement("update CompanyTable set companyName=?, totalShares=?, currentPrice=? where companyID=?");

			// CallableStatement cs =
			// c.prepareCall("{call updateCompanyTable(?,?,?,?)}");
			p.setString(1, comp.getCompanyName());
			p.setInt(2, comp.getTotalShares());

			p.setDouble(3, comp.getCurrentPrice());
			p.setString(4, comp.getCompanyID());

			int i = p.executeUpdate();

			p.close();
			closeConnection(c);

			return i;
			
		} catch (SQLException e) {
			System.out.println("SQLException here " + e);
			return -1;
		}
	}

	public ArrayList<Company> forms(String id) {
		ArrayList<Company> display = new ArrayList<Company>();

		String query = "SELECT * FROM COMPANYTABLE WHERE COMPANYID=?";

		c = getConnection();
		ResultSet rs = null;
		Company comp = new Company();
		try {
			p = c.prepareStatement(query);
			p.setString(1, id);
			rs = p.executeQuery();
			while (rs.next()) {

				String companyID = rs.getString(1);
				String companyName = rs.getString(2);
				double currentPrice = rs.getDouble(4);
				int availableShares = rs.getInt(5);
				String seller = rs.getString(6);

				comp.setCompanyID(companyID);
				comp.setCompanyName(companyName);
				comp.setCurrentPrice(currentPrice);
				comp.setAvailableShares(availableShares);
				comp.setSeller(seller);

				display.add(comp);

			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return display;

	}

	public int updateStockDetailsTable(Company comp) {
		c = getConnection();
		CallableStatement cs = null;

		try {
			p = c.prepareStatement("select totalShares from CompanyTable where companyID=?");

			p.setString(1, comp.getCompanyID());
			System.out.println(comp.getCompanyID());

			r = p.executeQuery();

			int prevShare, diffShare;
			

			if (r.next()) {
				prevShare = r.getInt("totalShares");

				p.close();

				if (comp.getTotalShares() > prevShare) {
					diffShare = comp.getTotalShares() - prevShare;
					
					p = c.prepareStatement("update StockDetailsTable set totalshares=(totalshares+?), currentPrice=?, dateTime2=SYSDATE where companyID=?");
					p.setInt(1, diffShare);
					p.setDouble(2, comp.getCurrentPrice());
					p.setString(3, comp.getCompanyID());
				} else {
					diffShare = prevShare - comp.getTotalShares();
					
					p = c.prepareStatement("update StockDetailsTable set totalShares=(totalShares-?), currentPrice=?, dateTime2=SYSDATE where companyID=?");
					p.setInt(1, diffShare);
					p.setDouble(2, comp.getCurrentPrice());
					p.setString(3, comp.getCompanyID());
				}

				int j = 0;
				j = p.executeUpdate();

				p.close();
				closeConnection(c);

				correctStockTable(comp.getCompanyID());

				return j;

			} else {
				p.close();
				closeConnection(c);

				return -1;
			}
		} catch (SQLException e) {
			System.out.println("SQLException334 " + e);
			e.printStackTrace();
			return -1;
		}
	}

	public void correctStockTable(String cID) {
		c = getConnection();

		try {
			p = c.prepareStatement("select totalShares from StockDetailsTable where companyID=?");
			p.setString(1, cID);
			r = p.executeQuery();

			r.next();

			int availShares = r.getInt("totalShares");

			r.close();
			p.close();
			int l = 0;
			if (availShares < 0) {
				p = c.prepareStatement("update StockDetailsTable set totalShares=0 where companyID=?");
				p.setString(1, cID);

				l = p.executeUpdate();
				p.close();
			}

			closeConnection(c);

		} catch (SQLException e) {
			System.out.println("SQLException1 " + e);

		}
	}

	public boolean deleteStock(String cID) {
		c = getConnection();

		try {
			int i = 0;

			p = c.prepareStatement("delete from USERSTOCKTABLE where companyID=?");
			p.setString(1, cID);

			i = p.executeUpdate();

			p.close();

			p = c.prepareStatement("delete from TransactionsTable where companyID=?");
			p.setString(1, cID);

			i = i + p.executeUpdate();

			p.close();

			p = c.prepareStatement("delete from StockDetailsTable where companyID=?");
			p.setString(1, cID);

			i = i + p.executeUpdate();

			p.close();

			p = c.prepareStatement("delete from CompanyTable where companyID=?");
			p.setString(1, cID);

			i = i + p.executeUpdate();

			p.close();
			closeConnection(c);

			return true;

		} catch (SQLException e) {
			System.out.println("SQLException2 " + e);
			return false;
		}
	}

	public ArrayList<Company> purchaseStocks() {
		c = getConnection();
		ArrayList<Company> alist = new ArrayList<Company>();
		try {
			p = c.prepareStatement("select companyID,companyName,seller,availableShares,currentPrice from CompanyTable");
			r = p.executeQuery();

			while (r.next()) {
				Company comp = new Company();
				comp.setCompanyID(r.getString(1));
				comp.setCompanyName(r.getString(2));
				comp.setSeller(r.getString(3));
				comp.setAvailableShares(r.getInt(4));
				comp.setCurrentPrice(r.getDouble(5));
				
				alist.add(comp);

			}

			r.close();
			p.close();
			closeConnection(c);
		

		} catch (SQLException e) {
			System.out.println("SQLException4 " + e);

		}
		return alist;

	}

	public Company getCompany(String cID) {
		c = getConnection();

		try {
			p = c.prepareStatement("select companyID, companyName, totalShares, currentPrice, availableShares, seller from CompanyTable where companyID=? ");
			p.setString(1, cID);

			r = p.executeQuery();

			Company comp = new Company();

			if (r.next() == true) {

				String companyID = r.getString(1);
				String companyName = r.getString(2);
				int totalShares = r.getInt(3);
				double currentPrice = r.getDouble(4);
				int availableShares = r.getInt(5);
				String seller = r.getString(6);
				// Timestamp dateTime;

				comp.setCompanyID(r.getString(1));
				comp.setCompanyName(r.getString(2));
				comp.setTotalShares(r.getInt(3));
				comp.setCurrentPrice(r.getDouble(4));
				comp.setAvailableShares(r.getInt(5));
				comp.setSeller(r.getString(6));

				Company comp1 = new Company(companyID, companyName,
						totalShares, currentPrice, availableShares, seller);

			}
			return comp;

		} catch (SQLException e) {
			System.out.println("SQLException3 " + e);
			return null;
		}
	}

	public int updateUserStocks(Company comp, User u, int shares) {
		c = getConnection();

		// System.out.println("In test"+u.getUserID() + comp.getCompanyID() +
		// shares);
		try {
			int i = 0;

			p = c.prepareStatement("select * from UserStockTable where userID=? and companyID=?");
			p.setString(1, u.getUserID());
			p.setString(2, comp.getCompanyID());

			r = p.executeQuery();

			if (r.next()) {
				r.close();
				p.close();

				System.out.println("Hello1");

				p = c.prepareStatement("update userStockTable set noofownedShares=noofownedShares+? where userID=? and companyID=?");
				p.setInt(1, shares);
				p.setString(2, u.getUserID());
				p.setString(3, comp.getCompanyID());

				i = p.executeUpdate();

			} else {
				r.close();
				p.close();

				p = c.prepareStatement("insert into userStockTable values(?,?,?,?,?)");
				p.setString(1, u.getUserID());
				p.setString(2, comp.getCompanyID());
				p.setString(3, comp.getCompanyName());
				p.setInt(4, shares);
				p.setDouble(5, comp.getCurrentPrice());

				i = p.executeUpdate();
			}
			System.out.println("i is "+i);
			
			
			p.close();
			closeConnection(c);

			return i;
			

		} catch (SQLException e) {
			System.out.println("SQLException999 " + e);
			return -1;
		}
	}

	public int addTransaction(Company comp, User u, int shares) {
		c=getConnection();
		String tid = "TI" + Math.round(Math.random() * 1000);
		Double txnprice = comp.getCurrentPrice() *shares* 0.01;
	
		int result=0;
		String query="insert into TransactionsTable values(?,current_timestamp,?,?,?,?,?,?,?)";
		
		try {
			p=c.prepareStatement(query);
			
			p.setString(1, tid);
			p.setString(3, comp.getSeller());
			p.setString(4, u.getUserID());
			p.setString(5, comp.getCompanyID());
			p.setString(6, comp.getCompanyName());
			p.setInt(7, shares);
			p.setDouble(8, txnprice);
			p.setDouble(9, comp.getCurrentPrice());
			
			
			result=p.executeUpdate();
			p.close();
			closeConnection(c);
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.err.println("Transactiontable insert error");
			e.printStackTrace();
		}
		
		
		return result;
	
	
	}

	public int updateStocks(Company comp, int shares) {
		c = getConnection();

		try {
			int i = 0;

			p = c.prepareStatement("update stockDetailsTable set totalShares=TOTALSHARES-? where companyID=?");
			p.setInt(1, shares);

			p.setString(2, comp.getCompanyID());

			i = p.executeUpdate();

			p.close();
			closeConnection(c);
			
			System.out.println("i1 is "+i);
			return i;

		} catch (SQLException e) {
			System.out.println("SQLException444 " + e);
			return -1;
		}
	}

	public int updateUserValue(User u) {
		c = getConnection();

		try {
			p = c.prepareStatement("update UserTable set newUser=? where userID=?");
			p.setInt(1, 1);
			p.setString(2, u.getUserID());

			int i = 0;
			i = p.executeUpdate();

			p.close();
			closeConnection(c);

			return i;
		} catch (SQLException e) {
			System.out.println("USer insert2 " + e);
			return -1;
		}
	}

	public ArrayList<UserStock> sellStocks(User u) {
		c = getConnection();
		ArrayList<UserStock> alist = new ArrayList<UserStock>();
		try {
			p = c.prepareStatement("select us.companyID, c.companyName, us.noofownedShares, c.currentPrice from CompanyTable c, UserStockTable us where c.companyID=us.companyID and us.userID=?");
			p.setString(1, u.getUserID());

			r = p.executeQuery();

			while (r.next()) {
				UserStock usrStk = new UserStock();

				usrStk.setCompanyID(r.getString(1));
				usrStk.setCompanyName(r.getString(2));
				usrStk.setNoOfOwnedShares(r.getInt(3));
				usrStk.setCurrentPrice(r.getDouble(4));

				alist.add(usrStk);
			}

			r.close();
			p.close();
			closeConnection(c);
			

		} catch (SQLException e) {
			System.out.println("SQLException555 " + e);
			return null;
		}
		return alist;

	}

	public int updateUserStocks2(Company comp, User u, int shares)
			throws MoreSharesException {
		c = getConnection();

		try {
			int i = 0;

			int ownedShares = 0;
			p = c.prepareStatement("select noofownedShares from USERSTOCKTABLE where companyID=? and userID=?");
			p.setString(1, comp.getCompanyID());
			p.setString(2, u.getUserID());

			r = p.executeQuery();

			r.next();

			ownedShares = r.getInt("noofownedShares");

			r.close();
			p.close();

			if (ownedShares > shares) {
				p = c.prepareStatement("update USERSTOCKTABLE set NOOFOWNEDSHARES=NOOFOWNEDSHARES-? where userID=? and companyID=?");
				p.setInt(1, shares);
				p.setString(2, u.getUserID());
				p.setString(3, comp.getCompanyID());

				i = p.executeUpdate();
				
				System.out.println("success");

				p.close();
			} else if (ownedShares == shares) {
				p = c.prepareStatement("delete from USERSTOCKTABLE where userID=? and companyID=?");
				p.setString(1, u.getUserID());
				p.setString(2, comp.getCompanyID());

				i = p.executeUpdate();
			} else if (ownedShares < shares) {
				i = -5;
			}

			closeConnection(c);

			return i;

		} catch (SQLException e) {
			System.out.println("SQLException66 " + e);
			return -1;
		}
	}

	public int updateStocks2(Company comp, User u, int shares) {
		c = getConnection();

		try {
			int i = 0;

			p = c.prepareStatement("update stockDetailsTable set totalShares=totalShares+? where companyID=?");
			p.setInt(1, shares);
			p.setString(2, comp.getCompanyID());

			i = p.executeUpdate();

			p.close();
			closeConnection(c);

			return i;

		} catch (SQLException e) {
			System.out.println("SQLException27 " + e);
			return -1;
		}
	}

	public boolean moreSharesExc(User u, String msg) {
		c = getConnection();

		try {
			p = c.prepareStatement("insert into warnings values(?, ?, ?, SYSDATE)");
			p.setString(1, "W" + Math.round(Math.random() * 1000));
			p.setString(2, u.getUserID());
			p.setString(3, msg);

			int i = 0;
			i = p.executeUpdate();

			p.close();
			closeConnection(c);

			return true;
		} catch (SQLException e) {
			System.out.println("USer insert77 " + e);
			return false;
		}
	}

	public ArrayList<Transaction> purchasePF(User u) {
		c = getConnection();

		try {
			p = c.prepareStatement("select * from transactionstable where buyerID=?");
			p.setString(1, u.getUserID());

			r = p.executeQuery();

			ArrayList<Transaction> al = new ArrayList<Transaction>();

			while (r.next()) {
				Transaction txn = new Transaction();
				txn.setTransactionID(r.getString(1));
				txn.setDateTime(r.getTimestamp(2));
				txn.setSellerID(r.getString(3));
				txn.setBuyerID(r.getString(4));
				txn.setCompanyID(r.getString("companyID"));
				txn.setShares(r.getInt(7));
				txn.setTxnPrice(r.getDouble(8));
				/*
				 * txn.setCompanyID(r.getString("companyID"));
				 * txn.setSellerID(r.getString("sellerID"));
				 * txn.setShares(r.getInt("shares"));
				 * txn.setTxnPrice(r.getDouble("price"));
				 * txn.setTransactionID(r.getString("tid"));
				 * txn.setDateTime(r.getTimestamp("dateTime4"));
				 */
				al.add(txn);
			}

			p.close();
			closeConnection(c);

			return al;
		} catch (SQLException e) {
			System.out.println("USer insert " + e);
			return null;
		}
	}

	public ArrayList<Transaction> sellPF(User u) {
		c = getConnection();

		try {
			p = c.prepareStatement("select * from transactionstable where sellerID=?");
			p.setString(1, u.getUserID());

			r = p.executeQuery();

			ArrayList<Transaction> al = new ArrayList<Transaction>();

			while (r.next()) {
				Transaction txn = new Transaction();
				/*
				 * txn.setCompanyID(r.getString("companyID"));
				 * txn.setBuyerID(r.getString("buyerID"));
				 * txn.setShares(r.getInt("shares"));
				 * txn.setTxnPrice(r.getDouble("price"));
				 * txn.setTransactionID(r.getString("tid"));
				 * txn.setDateTime(r.getTimestamp("dateTime4"));
				 */
				txn.setTransactionID(r.getString("tid"));
				txn.setDateTime(r.getTimestamp("dateTime4"));
				txn.setSellerID("sellerID");
				txn.setBuyerID(r.getString("buyerID"));
				txn.setCompanyID(r.getString("companyID"));
				txn.setShares(r.getInt("shares"));
				txn.setTxnPrice(r.getDouble("price"));
				al.add(txn);
			}

			p.close();
			closeConnection(c);

			return al;
		} catch (SQLException e) {
			System.out.println("USer insert " + e);
			return null;
		}
	}

	public ArrayList<Transaction> genReport() {
		c = getConnection();

		try {
			p = c.prepareStatement("select * from transactionstable");

			r = p.executeQuery();

			ArrayList<Transaction> al = new ArrayList<Transaction>();

			while (r.next()) {
				Transaction txn = new Transaction();
				txn.setTransactionID(r.getString(1));
				txn.setDateTime(r.getTimestamp(2));
				txn.setSellerID(r.getString(3));
				txn.setBuyerID(r.getString(4));
				txn.setCompanyID(r.getString(5));
				txn.setShares(r.getInt(7));
				txn.setTxnPrice(r.getDouble(8));

				al.add(txn);
			}

			p.close();
			closeConnection(c);

			return al;
		} catch (SQLException e) {
			System.out.println("USer insert " + e);
			e.printStackTrace();
			return null;
		}
	}

	public boolean approveTrade(User u, Company comp, int shares) {
		c = getConnection();

		try {
			p = c.prepareStatement("select newuser from usertable where userID=?");
			p.setString(1, u.getUserID());

			r = p.executeQuery();

			r.next();

			int ok = r.getInt("newuser");

			r.close();
			p.close();

			if (ok == 0) {
				p = c.prepareStatement("select currentPrice from StockDetailsTable where companyID=?");
				p.setString(1, comp.getCompanyID());

				r = p.executeQuery();
				r.next();
				Double currPrice = r.getDouble("currentPrice");

				Double tradeVal = currPrice * shares;

				if (tradeVal > 100000)
					return false;
				else
					return true;
			} else
				return true;

		} catch (SQLException e) {
			System.out.println("USer insert " + e);
			return false;
		}
	}

	public int resetPass(User u, String oldPass, String newPass, String confPass) {
		int i = 0;
		c = getConnection();
		try {

			p = c.prepareStatement("select password from UserTable where userID=?");

			p.setString(1, u.getUserID());

			r = p.executeQuery();
			r.next();
			String pass = r.getString("password");

			r.close();
			p.close();

			if (newPass.equals(confPass)) {
				if (oldPass.equals(pass)) {
					c = getConnection();
					p = c.prepareStatement("update UserTable set password=? where userID=?");
					{
						p.setString(1, newPass);
						p.setString(2, u.getUserID());
						i = p.executeUpdate();
					}
				}
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		return i;

	}
}