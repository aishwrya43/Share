package com.techM.shareChacha.controller;


import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techM.shareChachaBeans.Company;
import com.techM.shareChachaBeans.User;
import com.techM.shareChachaDB.UserDB;

/**
 * Servlet implementation class AddStocksServlet
 */
public class AddStocksServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddStocksServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession(false);
		int i = 0;
		
		try {
		Company comp = new Company();
		
		comp.setCompanyName(request.getParameter("companyName"));
		comp.setTotalShares(Integer.parseInt(request.getParameter("totalShares")));
		comp.setCurrentPrice(Double.parseDouble(request.getParameter("currentPrice")));
		comp.setCompanyID(request.getParameter("companyName").substring(0,4)+Math.round(Math.random()*10000));
				
		UserDB uDB = new UserDB();
		
		
		User u = (User) session.getAttribute( "userObj");
		
		out.print(u.getUserName());
		
		i = uDB.addStock(comp, u.getUserID());
		
		if( i == 2 ) {
			session.setAttribute("row", "1 company added");
			
			RequestDispatcher rd = request.getRequestDispatcher("/addStocks.jsp");
			rd.forward(request, response);
		}
		else {
			throw new Exception();
		}
		} catch (Exception e) {
			session.setAttribute("status", i + " Company could not be added. Please try again..");
			
			RequestDispatcher rd = request.getRequestDispatcher("/addStocks.jsp");
			rd.forward(request, response);
		}
		
	}
}


