package com.techM.shareChacha.controller;


import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.techM.shareChacha.MoreSharesException;
import com.techM.shareChachaBeans.Company;
import com.techM.shareChachaBeans.User;
import com.techM.shareChachaDB.UserDB;

/**
 * Servlet implementation class PurchaseStocksServlet1
 */
public class PurchaseStocksServlet1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public PurchaseStocksServlet1() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		//PrintWriter out=response.getWriter();
		
		HttpSession session=request.getSession(false);
		
		

	//	HttpSession session = request.getSession(false);
	//	session.setAttribute("company2", comp);
		
		try {
			UserDB uDB = new UserDB();
			
			String m_companyid = request.getParameter("companyID");
			
		ArrayList<Company> alist=new ArrayList<Company>();
		User u = (User) session.getAttribute("userObj");
		
		//Company comp = (Company) session.getAttribute("company2");
		
		Company comp = (Company) uDB.getCompany(m_companyid);
		
		
		
		
		
	
		
		int shares = 0;
		shares = Integer.parseInt(request.getParameter("noOfShares"));
		
		//System.out.println("no of shares" +shares);
		
		double currPrice =  0.0;
		currPrice = Double.parseDouble(request.getParameter("currentPrice"));
		
	//	System.out.println("current price" +currPrice);
		
		int availableShares = 0;
		availableShares = Integer.parseInt(request.getParameter("availableShares"));
		
	//	System.out.println("available shares"+availableShares);
		
		try {
			if( availableShares >= shares ) {
				try {
					if( (currPrice * shares) > ((double) 100000) )						
						throw new MoreSharesException("Intial trade limit is Rs. 100000 only");
					
					else {
						int i = 0;
				
						
						
						i = uDB.updateUserStocks(comp, u, shares);	
					//	i = i + uDB.addTransaction(comp, u, shares );
						i = i + uDB.updateStocks(comp, shares);
					//	i = i + uDB.updateUserValue(u);		
				
						if( i == 2 ) {
							session.setAttribute("status2","Purchase successful");
							RequestDispatcher rd=request.getRequestDispatcher("PurchasePageServlet1");
							rd.forward(request,response);
						}
						else {
							session.setAttribute("status2","Error while purchasing. Please try again..");
							RequestDispatcher rd=request.getRequestDispatcher("/purchase.jsp");
							rd.forward(request,response);
						}
					}
				} catch (MoreSharesException me) {
					boolean sts = uDB.moreSharesExc(u, "Intial trade limit is Rs. 100000 only" );
					if( sts ) {
						System.out.println(sts);
						session.setAttribute("status5", "Intial trade limit is Rs. 100000 only");
						RequestDispatcher rd=request.getRequestDispatcher("/getShares.jsp");
						rd.include(request,response);
					}
				}
			}
			else 
				throw new MoreSharesException("Insufficient shares");
		} catch (MoreSharesException me) {
			boolean sts = uDB.moreSharesExc(u, "Insufficient shares" );
			if( sts ) {
				session.setAttribute("status5", "Insufficient shares");
				RequestDispatcher rd=request.getRequestDispatcher("/getShares.jsp");
				rd.include(request,response);
			}
		}
		} catch ( Exception e) {
			session.setAttribute("status5", "Please try again");
			RequestDispatcher rd=request.getRequestDispatcher("/getShares.jsp");
			rd.include(request,response);
		}
	}

}
